'use client'

import { useState, useRef, KeyboardEvent } from 'react'
import { motion, AnimatePresence, Reorder } from 'framer-motion'
import { CookingPotIcon as Kitchen, Bath, Warehouse, Bed, Sofa, Trees, Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/use-toast'
import confetti from 'canvas-confetti'

interface Task {
  id: string
  text: string
  completed: boolean
}

interface Room {
  id: string
  name: string
  icon: React.ComponentType<{ className?: string }>
  tasks: Task[]
}

const initialRooms: Room[] = [
  {
    id: 'kitchen',
    name: 'Kitchen',
    icon: Kitchen,
    tasks: [
      { id: 'k1', text: 'Clean countertops and sink', completed: false },
      { id: 'k2', text: 'Sweep and mop floors', completed: false },
      { id: 'k3', text: 'Empty dishwasher', completed: false },
    ],
  },
  {
    id: 'bathroom',
    name: 'Bathroom',
    icon: Bath,
    tasks: [
      { id: 'b1', text: 'Clean toilet and sink', completed: false },
      { id: 'b2', text: 'Scrub shower/bathtub', completed: false },
      { id: 'b3', text: 'Replace towels', completed: false },
    ],
  },
  {
    id: 'outdoor',
    name: 'Outdoor',
    icon: Trees,
    tasks: [
      { id: 'o1', text: 'Mow lawn', completed: false },
      { id: 'o2', text: 'Water plants', completed: false },
      { id: 'o3', text: 'Clean patio', completed: false },
    ],
  },
  {
    id: 'bedroom',
    name: 'Bedroom',
    icon: Bed,
    tasks: [
      { id: 'bd1', text: 'Make bed', completed: false },
      { id: 'bd2', text: 'Dust furniture', completed: false },
      { id: 'bd3', text: 'Vacuum floor', completed: false },
    ],
  },
  {
    id: 'living',
    name: 'Living Room',
    icon: Sofa,
    tasks: [
      { id: 'l1', text: 'Vacuum sofa', completed: false },
      { id: 'l2', text: 'Dust TV and shelves', completed: false },
      { id: 'l3', text: 'Organize magazines', completed: false },
    ],
  },
  {
    id: 'storage',
    name: 'Storage',
    icon: Warehouse,
    tasks: [
      { id: 's1', text: 'Organize tools', completed: false },
      { id: 's2', text: 'Check supplies', completed: false },
      { id: 's3', text: 'Clean shelves', completed: false },
    ],
  },
]

export default function HouseholdTodo() {
  const [rooms, setRooms] = useState<Room[]>(initialRooms)
  const [selectedRoom, setSelectedRoom] = useState<Room>(rooms[0])
  const [newTask, setNewTask] = useState('')
  const { toast } = useToast()
  const inputRef = useRef<HTMLInputElement>(null)

  const handleTaskToggle = (taskId: string) => {
    setRooms((prevRooms) => {
      const updatedRooms = prevRooms.map((room) => {
        if (room.id === selectedRoom.id) {
          const updatedTasks = room.tasks.map((task) => {
            if (task.id === taskId) {
              const updatedTask = { ...task, completed: !task.completed }
              if (updatedTask.completed) {
                toast({
                  title: 'Task Completed!',
                  description: updatedTask.text,
                })
                confetti({
                  particleCount: 100,
                  spread: 70,
                  origin: { y: 0.6 },
                })
              }
              return updatedTask
            }
            return task
          })
          return { ...room, tasks: updatedTasks }
        }
        return room
      })
      setSelectedRoom(updatedRooms.find((room) => room.id === selectedRoom.id) || updatedRooms[0])
      return updatedRooms
    })
  }

  const handleAddTask = () => {
    if (newTask.trim()) {
      setRooms((prevRooms) => {
        const updatedRooms = prevRooms.map((room) => {
          if (room.id === selectedRoom.id) {
            const newId = `${room.id[0]}${room.tasks.length + 1}`
            const updatedTasks = [...room.tasks, { id: newId, text: newTask.trim(), completed: false }]
            return { ...room, tasks: updatedTasks }
          }
          return room
        })
        setSelectedRoom(updatedRooms.find((room) => room.id === selectedRoom.id) || updatedRooms[0])
        return updatedRooms
      })
      setNewTask('')
      inputRef.current?.focus()
    }
  }

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddTask()
    }
  }

  const handleDeleteTask = (taskId: string) => {
    setRooms((prevRooms) => {
      const updatedRooms = prevRooms.map((room) => {
        if (room.id === selectedRoom.id) {
          const updatedTasks = room.tasks.filter((task) => task.id !== taskId)
          return { ...room, tasks: updatedTasks }
        }
        return room
      })
      setSelectedRoom(updatedRooms.find((room) => room.id === selectedRoom.id) || updatedRooms[0])
      return updatedRooms
    })
  }

  const handleReorderTasks = (reorderedTasks: Task[]) => {
    setRooms((prevRooms) => {
      const updatedRooms = prevRooms.map((room) => {
        if (room.id === selectedRoom.id) {
          return { ...room, tasks: reorderedTasks }
        }
        return room
      })
      setSelectedRoom(updatedRooms.find((room) => room.id === selectedRoom.id) || updatedRooms[0])
      return updatedRooms
    })
  }

  const isRoomCompleted = (room: Room) => room.tasks.length > 0 && room.tasks.every((task) => task.completed)

  return (
    <div className="max-w-2xl mx-auto p-4 font-inter">
      <div className="flex justify-start gap-4 mb-8 overflow-x-auto pb-2">
        {rooms.map((room) => {
          const Icon = room.icon
          const isCompleted = isRoomCompleted(room)
          return (
            <motion.button
              key={room.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedRoom(room)}
              className={cn(
                "p-4 rounded-full transition-colors flex-shrink-0",
                selectedRoom.id === room.id
                  ? isCompleted
                    ? "bg-yellow-500 text-white"
                    : "bg-blue-500 text-white"
                  : isCompleted
                  ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-200 dark:bg-yellow-900 dark:text-yellow-100 dark:hover:bg-yellow-800"
                  : "bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700"
              )}
            >
              <Icon className="w-6 h-6" />
              <span className="sr-only">{room.name}</span>
            </motion.button>
          )
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={selectedRoom.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
        >
          <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-50 mb-8">
            {selectedRoom.name}
          </h1>

          <div className="flex gap-2 mb-6">
            <Input
              type="text"
              placeholder="Add a new task"
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              onKeyPress={handleKeyPress}
              ref={inputRef}
              className="flex-grow"
            />
            <Button onClick={handleAddTask}>Add</Button>
          </div>

          <Reorder.Group
            axis="y"
            values={selectedRoom.tasks}
            onReorder={handleReorderTasks}
            className="space-y-6"
          >
            {selectedRoom.tasks.map((task) => (
              <Reorder.Item
                key={task.id}
                value={task}
                className="flex items-center gap-3 pb-4 border-b border-gray-200 dark:border-gray-700"
              >
                <Checkbox
                  id={`${selectedRoom.id}-${task.id}`}
                  checked={task.completed}
                  onCheckedChange={() => handleTaskToggle(task.id)}
                />
                <label
                  htmlFor={`${selectedRoom.id}-${task.id}`}
                  className={cn(
                    "flex-grow text-gray-700 dark:text-gray-300 leading-normal cursor-move",
                    task.completed && "line-through text-gray-400 dark:text-gray-600"
                  )}
                >
                  {task.text}
                </label>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDeleteTask(task.id)}
                  className="text-gray-500 hover:text-red-500 dark:text-gray-400 dark:hover:text-red-400"
                >
                  <Trash2 className="h-4 w-4" />
                  <span className="sr-only">Delete task</span>
                </Button>
              </Reorder.Item>
            ))}
          </Reorder.Group>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

