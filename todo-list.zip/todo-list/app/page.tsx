import HouseholdTodo from '@/components/household-todo'

export default function Page() {
  return (
    <main className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <HouseholdTodo />
    </main>
  )
}

